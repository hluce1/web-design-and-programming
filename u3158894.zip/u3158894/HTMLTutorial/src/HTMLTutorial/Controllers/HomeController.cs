﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace HTMLTutorial.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult CSS3()
        {
            return View();
        }

        public IActionResult GoogleMap()
        {
            return View();
        }

        public IActionResult jQuery()
        {
            return View();
        }

        public IActionResult JavaScript()
        {
            return View();
        }

        public IActionResult Price()
        {
            return View();
        }

        public IActionResult Location()
        {
            return View();
        }

        public IActionResult Dishes()
        {
            return View();
        }


        public IActionResult Cuisine()
        {
            return View();
        }


        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Restaurants()
        {
            return View();
        }

        public IActionResult Reviews()
        {
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }
    }
}
